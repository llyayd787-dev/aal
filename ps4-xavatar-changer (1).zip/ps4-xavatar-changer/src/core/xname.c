#include "xname.h"
#include <string.h>
#include <strings.h>

static size_t cp_len(unsigned char c) { return c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 1; }

void xname_short(const char *path, char *out, size_t out_size, int max_chars)
{
    if (!out || out_size == 0) return;
    out[0] = 0;
    if (!path) return;
    const char *base = path, *s;
    for (s = path; *s; s++) if (*s == '/') base = s + 1;
    char tmp[256];
    size_t n = strlen(base);
    if (n >= sizeof(tmp)) n = sizeof(tmp) - 1;
    memcpy(tmp, base, n); tmp[n] = 0;
    if (n > 8 && strcasecmp(tmp + n - 8, ".xavatar") == 0) tmp[n -= 8] = 0;
    const char *name = tmp;
    if (n > 7 && strncasecmp(name, "avatar_", 7) == 0) { name += 7; n -= 7; }

    /* count characters */
    int chars = 0;
    for (size_t i = 0; i < n; i += cp_len((unsigned char)name[i])) chars++;
    if (max_chars < 6) max_chars = 6;
    if (chars <= max_chars) { strncpy(out, name, out_size - 1); out[out_size - 1] = 0; return; }

    int head = (max_chars - 2) * 6 / 10, tail = max_chars - 2 - head;
    size_t i = 0; int c = 0; size_t o = 0;
    while (c < head && i < n) { size_t l = cp_len((unsigned char)name[i]); if (o + l + 3 >= out_size) break; memcpy(out + o, name + i, l); o += l; i += l; c++; }
    out[o++] = '.'; out[o++] = '.';
    /* find start of the last `tail` characters */
    size_t starts[64]; int sc = 0;
    for (size_t k = 0; k < n && sc < 64; k += cp_len((unsigned char)name[k])) starts[sc++] = k;
    size_t from = starts[sc - tail];
    while (from < n && o + 1 < out_size) out[o++] = name[from++];
    out[o] = 0;
}
