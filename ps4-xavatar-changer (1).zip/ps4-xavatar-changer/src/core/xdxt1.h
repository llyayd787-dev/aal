#ifndef XDXT1_H
#define XDXT1_H
#include <stddef.h>
#include <stdint.h>
/* Decodes the first mip level of a DXT1 DDS file to RGBA8888 (malloc'd, w*h*4). Returns NULL on error. */
uint8_t *xdxt1_decode(const uint8_t *dds, size_t len, int *w, int *h);
#endif
