#include "xdxt1.h"
#include <stdlib.h>
#include <string.h>

static uint32_t u32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

static void c565(uint16_t c, uint8_t *rgb)
{
    unsigned r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31;
    rgb[0] = (uint8_t)((r << 3) | (r >> 2));
    rgb[1] = (uint8_t)((g << 2) | (g >> 4));
    rgb[2] = (uint8_t)((b << 3) | (b >> 2));
}

uint8_t *xdxt1_decode(const uint8_t *dds, size_t len, int *w, int *h)
{
    if (len < 128 || memcmp(dds, "DDS ", 4) != 0 || u32(dds + 4) != 124) return NULL;
    if (memcmp(dds + 84, "DXT1", 4) != 0) return NULL;
    uint32_t height = u32(dds + 12), width = u32(dds + 16);
    if (width == 0 || height == 0 || width > 2048 || height > 2048) return NULL;
    size_t bw = (width + 3) / 4, bh = (height + 3) / 4;
    if (128 + bw * bh * 8 > len) return NULL;
    uint8_t *out = (uint8_t *)calloc((size_t)width * height, 4);
    if (!out) return NULL;
    const uint8_t *src = dds + 128;
    for (size_t by = 0; by < bh; by++) for (size_t bx = 0; bx < bw; bx++, src += 8) {
        uint16_t c0 = (uint16_t)(src[0] | (src[1] << 8)), c1 = (uint16_t)(src[2] | (src[3] << 8));
        uint8_t pal[4][4];
        c565(c0, pal[0]); c565(c1, pal[1]);
        pal[0][3] = pal[1][3] = 255;
        if (c0 > c1) {
            for (int i = 0; i < 3; i++) {
                pal[2][i] = (uint8_t)((2 * pal[0][i] + pal[1][i]) / 3);
                pal[3][i] = (uint8_t)((pal[0][i] + 2 * pal[1][i]) / 3);
            }
            pal[2][3] = pal[3][3] = 255;
        } else {
            for (int i = 0; i < 3; i++) { pal[2][i] = (uint8_t)((pal[0][i] + pal[1][i]) / 2); pal[3][i] = 0; }
            pal[2][3] = 255; pal[3][3] = 0;
        }
        uint32_t bits = u32(src + 4);
        for (int py = 0; py < 4; py++) for (int px = 0; px < 4; px++, bits >>= 2) {
            size_t x = bx * 4 + px, y = by * 4 + py;
            if (x < width && y < height) memcpy(out + (y * width + x) * 4, pal[bits & 3], 4);
        }
    }
    *w = (int)width; *h = (int)height;
    return out;
}
