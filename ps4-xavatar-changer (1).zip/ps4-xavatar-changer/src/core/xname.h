#ifndef XNAME_H
#define XNAME_H
#include <stddef.h>
/* Display name from a file path: drops folders, ".xavatar", a leading "avatar_",
 * and shortens long names in the middle with ".." (UTF-8 safe). max_chars counts characters. */
void xname_short(const char *path, char *out, size_t out_size, int max_chars);
#endif
