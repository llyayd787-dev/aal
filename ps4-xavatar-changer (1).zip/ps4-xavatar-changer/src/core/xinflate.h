#ifndef XINFLATE_H
#define XINFLATE_H
#include <stddef.h>
#include <stdint.h>
/* Raw DEFLATE (RFC 1951) decoder. dst must hold exactly the expected output.
 * Returns 0 on success, negative on error. Public-domain style algorithm after "puff". */
int xinflate(const uint8_t *src, size_t srclen, uint8_t *dst, size_t dstlen);
uint32_t xcrc32(const uint8_t *buf, size_t len);
#endif
