#include "xinflate.h"
#include <string.h>

typedef struct { const uint8_t *src; size_t len, pos; uint32_t buf; int cnt; } bits_t;
typedef struct { uint16_t count[16]; uint16_t symbol[288]; } huff_t;

static int getbits(bits_t *s, int need, uint32_t *out)
{
    uint32_t v = s->buf;
    while (s->cnt < need) {
        if (s->pos >= s->len) return -1;
        v |= (uint32_t)s->src[s->pos++] << s->cnt;
        s->cnt += 8;
    }
    s->buf = v >> need;
    s->cnt -= need;
    *out = v & ((1u << need) - 1u);
    return 0;
}

static int decode(bits_t *s, const huff_t *h)
{
    int code = 0, first = 0, index = 0;
    for (int len = 1; len <= 15; len++) {
        uint32_t b;
        if (getbits(s, 1, &b)) return -1;
        code |= (int)b;
        int count = h->count[len];
        if (code - count < first) return h->symbol[index + (code - first)];
        index += count; first += count; first <<= 1; code <<= 1;
    }
    return -1;
}

static int build(huff_t *h, const uint16_t *length, int n)
{
    uint16_t offs[16];
    memset(h->count, 0, sizeof(h->count));
    for (int i = 0; i < n; i++) h->count[length[i]]++;
    if (h->count[0] == n) return 0;
    int left = 1;
    for (int len = 1; len <= 15; len++) { left <<= 1; left -= h->count[len]; if (left < 0) return -1; }
    offs[1] = 0;
    for (int len = 1; len < 15; len++) offs[len + 1] = (uint16_t)(offs[len] + h->count[len]);
    for (int i = 0; i < n; i++) if (length[i]) h->symbol[offs[length[i]]++] = (uint16_t)i;
    return left;
}

static const uint16_t LBASE[29] = {3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
static const uint16_t LEXT[29]  = {0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
static const uint16_t DBASE[30] = {1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
static const uint16_t DEXT[30]  = {0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};

static int codes(bits_t *s, uint8_t *dst, size_t dstlen, size_t *op, const huff_t *lc, const huff_t *dc)
{
    for (;;) {
        int sym = decode(s, lc);
        if (sym < 0) return -1;
        if (sym < 256) {
            if (*op >= dstlen) return -2;
            dst[(*op)++] = (uint8_t)sym;
        } else if (sym == 256) {
            return 0;
        } else {
            sym -= 257;
            if (sym >= 29) return -3;
            uint32_t e;
            if (getbits(s, LEXT[sym], &e)) return -1;
            size_t len = LBASE[sym] + e;
            int ds = decode(s, dc);
            if (ds < 0 || ds >= 30) return -4;
            if (getbits(s, DEXT[ds], &e)) return -1;
            size_t dist = DBASE[ds] + e;
            if (dist > *op) return -5;
            if (*op + len > dstlen) return -2;
            for (size_t i = 0; i < len; i++) { dst[*op] = dst[*op - dist]; (*op)++; }
        }
    }
}

static int fixed_block(bits_t *s, uint8_t *dst, size_t dstlen, size_t *op)
{
    huff_t lc, dc;
    uint16_t l[288];
    int i;
    for (i = 0; i < 144; i++) l[i] = 8;
    for (; i < 256; i++) l[i] = 9;
    for (; i < 280; i++) l[i] = 7;
    for (; i < 288; i++) l[i] = 8;
    build(&lc, l, 288);
    for (i = 0; i < 30; i++) l[i] = 5;
    build(&dc, l, 30);
    return codes(s, dst, dstlen, op, &lc, &dc);
}

static int dynamic_block(bits_t *s, uint8_t *dst, size_t dstlen, size_t *op)
{
    static const uint8_t ORDER[19] = {16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
    uint16_t lengths[320];
    uint32_t nlen, ndist, ncode, v;
    if (getbits(s, 5, &nlen) || getbits(s, 5, &ndist) || getbits(s, 4, &ncode)) return -1;
    nlen += 257; ndist += 1; ncode += 4;
    if (nlen > 286 || ndist > 30) return -1;
    int idx;
    for (idx = 0; idx < (int)ncode; idx++) { if (getbits(s, 3, &v)) return -1; lengths[ORDER[idx]] = (uint16_t)v; }
    for (; idx < 19; idx++) lengths[ORDER[idx]] = 0;
    huff_t lc, dc;
    if (build(&lc, lengths, 19) != 0) return -1;
    idx = 0;
    while (idx < (int)(nlen + ndist)) {
        int sym = decode(s, &lc);
        if (sym < 0) return -1;
        if (sym < 16) lengths[idx++] = (uint16_t)sym;
        else {
            uint16_t prev = 0; int rep;
            if (sym == 16) { if (idx == 0) return -1; prev = lengths[idx - 1]; if (getbits(s, 2, &v)) return -1; rep = 3 + (int)v; }
            else if (sym == 17) { if (getbits(s, 3, &v)) return -1; rep = 3 + (int)v; }
            else { if (getbits(s, 7, &v)) return -1; rep = 11 + (int)v; }
            if (idx + rep > (int)(nlen + ndist)) return -1;
            while (rep--) lengths[idx++] = prev;
        }
    }
    if (lengths[256] == 0) return -1;
    int r = build(&lc, lengths, (int)nlen);
    if (r < 0 || (r > 0 && (int)nlen - lc.count[0] != 1)) return -1;
    r = build(&dc, lengths + nlen, (int)ndist);
    if (r < 0 || (r > 0 && (int)ndist - dc.count[0] != 1)) return -1;
    return codes(s, dst, dstlen, op, &lc, &dc);
}

int xinflate(const uint8_t *src, size_t srclen, uint8_t *dst, size_t dstlen)
{
    bits_t s = { src, srclen, 0, 0, 0 };
    size_t op = 0;
    uint32_t last, type, v;
    do {
        if (getbits(&s, 1, &last) || getbits(&s, 2, &type)) return -1;
        int r;
        if (type == 0) {
            s.buf = 0; s.cnt = 0;
            if (s.pos + 4 > s.len) return -1;
            unsigned len = src[s.pos] | (src[s.pos + 1] << 8);
            unsigned nl  = src[s.pos + 2] | (src[s.pos + 3] << 8);
            s.pos += 4;
            if (len != (~nl & 0xFFFFu)) return -1;
            if (s.pos + len > s.len || op + len > dstlen) return -1;
            memcpy(dst + op, src + s.pos, len); s.pos += len; op += len; r = 0;
        } else if (type == 1) r = fixed_block(&s, dst, dstlen, &op);
        else if (type == 2) r = dynamic_block(&s, dst, dstlen, &op);
        else return -1;
        if (r) return r < 0 ? r : -1;
        (void)v;
    } while (!last);
    return op == dstlen ? 0 : -6;
}

uint32_t xcrc32(const uint8_t *buf, size_t len)
{
    static uint32_t table[256];
    static int ready = 0;
    if (!ready) {
        for (uint32_t i = 0; i < 256; i++) {
            uint32_t c = i;
            for (int k = 0; k < 8; k++) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : c >> 1;
            table[i] = c;
        }
        ready = 1;
    }
    uint32_t crc = 0xFFFFFFFFu;
    for (size_t i = 0; i < len; i++) crc = table[(crc ^ buf[i]) & 0xFF] ^ (crc >> 8);
    return crc ^ 0xFFFFFFFFu;
}
