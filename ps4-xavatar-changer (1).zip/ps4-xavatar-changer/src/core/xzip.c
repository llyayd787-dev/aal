#include "xzip.h"
#include "xinflate.h"
#include <stdlib.h>
#include <string.h>

static uint16_t u16(const uint8_t *p) { return (uint16_t)(p[0] | (p[1] << 8)); }
static uint32_t u32(const uint8_t *p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }

int xzip_open(xzip_t *z, const uint8_t *buf, size_t size)
{
    if (size < 22) return -1;
    size_t lo = size > 22 + 65535 ? size - 22 - 65535 : 0;
    for (size_t i = size - 22 + 1; i-- > lo; ) {
        if (u32(buf + i) == 0x06054b50u) {
            z->data = buf; z->size = size;
            z->count = u16(buf + i + 10);
            z->cd_off = u32(buf + i + 16);
            if (z->cd_off >= size) return -2;
            return 0;
        }
    }
    return -3;
}

int xzip_entry(const xzip_t *z, int index, xzip_entry_t *out)
{
    size_t p = z->cd_off;
    for (int i = 0; i <= index && i < z->count; i++) {
        if (p + 46 > z->size || u32(z->data + p) != 0x02014b50u) return -1;
        unsigned nl = u16(z->data + p + 28), el = u16(z->data + p + 30), cl = u16(z->data + p + 32);
        if (p + 46 + nl + el + cl > z->size) return -1;
        if (i == index) {
            memset(out, 0, sizeof(*out));
            out->method = u16(z->data + p + 10);
            out->crc = u32(z->data + p + 16);
            out->csize = u32(z->data + p + 20);
            out->usize = u32(z->data + p + 24);
            out->local_off = u32(z->data + p + 42);
            size_t n = nl < sizeof(out->name) - 1 ? nl : sizeof(out->name) - 1;
            memcpy(out->name, z->data + p + 46, n);
            out->name[n] = 0;
            return 0;
        }
        p += 46 + nl + el + cl;
    }
    return -2;
}

int xzip_find(const xzip_t *z, const char *name, xzip_entry_t *out)
{
    for (int i = 0; i < z->count; i++)
        if (xzip_entry(z, i, out) == 0 && strcmp(out->name, name) == 0) return 0;
    return -1;
}

uint8_t *xzip_extract(const xzip_t *z, const xzip_entry_t *e, size_t *len)
{
    size_t p = e->local_off;
    if (p + 30 > z->size || u32(z->data + p) != 0x04034b50u) return NULL;
    size_t start = p + 30 + u16(z->data + p + 26) + u16(z->data + p + 28);
    if (start + e->csize > z->size || e->usize > (16u << 20)) return NULL;
    uint8_t *out = (uint8_t *)malloc(e->usize ? e->usize : 1);
    if (!out) return NULL;
    int ok = 0;
    if (e->method == 0 && e->csize == e->usize) { memcpy(out, z->data + start, e->usize); ok = 1; }
    else if (e->method == 8) ok = xinflate(z->data + start, e->csize, out, e->usize) == 0;
    if (!ok || xcrc32(out, e->usize) != e->crc) { free(out); return NULL; }
    *len = e->usize;
    return out;
}
