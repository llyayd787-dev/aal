#ifndef XZIP_H
#define XZIP_H
#include <stddef.h>
#include <stdint.h>
typedef struct { const uint8_t *data; size_t size; uint32_t cd_off; uint16_t count; } xzip_t;
typedef struct { char name[128]; uint16_t method; uint32_t crc, csize, usize, local_off; } xzip_entry_t;
int  xzip_open(xzip_t *z, const uint8_t *buf, size_t size);                  /* 0 = ok */
int  xzip_entry(const xzip_t *z, int index, xzip_entry_t *out);              /* 0 = ok, iterates central dir */
int  xzip_find(const xzip_t *z, const char *name, xzip_entry_t *out);        /* 0 = found */
uint8_t *xzip_extract(const xzip_t *z, const xzip_entry_t *e, size_t *len);  /* malloc'd, CRC-verified, or NULL */
#endif
