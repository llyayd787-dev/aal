/*
 * XAvatar Changer - Diagnostic build (v0.1)
 * Uses ONLY standard C / POSIX calls (musl libc). No Sony-specific APIs.
 * Purpose: find out on the real console (PS4 13.52 + GoldHEN):
 *   1. where .xavatar files are,
 *   2. what local profile folders exist and what they contain,
 *   3. whether the app may write there (safe test: rewrite a file with its own bytes),
 *   4. make a backup of the current avatar files.
 * Output: /data/xavatar/diag_report.txt  (and a copy on USB if one is present)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#ifndef ROOT_DATA
#define ROOT_DATA     "/data"
#endif
#ifndef ROOT_PROFILE
#define ROOT_PROFILE  "/system_data/priv/cache/profile"
#endif
#ifndef ROOT_HOME
#define ROOT_HOME     "/user/home"
#endif
#ifndef ROOT_USB
#define ROOT_USB      "/mnt/usb"   /* + 0..7 */
#endif

#define WORK_DIR   ROOT_DATA "/xavatar"
#define REPORT     WORK_DIR "/diag_report.txt"
#define BACKUP_DIR WORK_DIR "/backup"

static FILE *g_log = NULL;

static void say(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    if (g_log) {
        va_start(ap, fmt);
        vfprintf(g_log, fmt, ap);
        va_end(ap);
        fflush(g_log);
    }
}

static int mkdir_p(const char *path)
{
    char tmp[1024];
    size_t n = strlen(path);
    if (n == 0 || n >= sizeof(tmp)) return -1;
    memcpy(tmp, path, n + 1);
    for (size_t i = 1; i < n; i++) {
        if (tmp[i] == '/') {
            tmp[i] = 0;
            if (mkdir(tmp, 0777) != 0 && errno != EEXIST) return -1;
            tmp[i] = '/';
        }
    }
    if (mkdir(tmp, 0777) != 0 && errno != EEXIST) return -1;
    return 0;
}

static int is_dir(const char *p)
{
    struct stat st;
    return stat(p, &st) == 0 && S_ISDIR(st.st_mode);
}

static int has_ext(const char *name, const char *ext)
{
    size_t a = strlen(name), b = strlen(ext);
    if (a < b) return 0;
    for (size_t i = 0; i < b; i++) {
        char c = name[a - b + i];
        if (c >= 'A' && c <= 'Z') c = (char)(c + 32);
        if (c != ext[i]) return 0;
    }
    return 1;
}

/* ---- 1. find .xavatar files ------------------------------------------ */
static int g_xav_count = 0;

static void scan_xavatar(const char *dir, int depth)
{
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.') continue;
        char path[1024];
        if (snprintf(path, sizeof(path), "%s/%s", dir, e->d_name) >= (int)sizeof(path)) continue;
        struct stat st;
        if (stat(path, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) {
            if (depth > 0) scan_xavatar(path, depth - 1);
        } else if (has_ext(e->d_name, ".xavatar")) {
            if (g_xav_count < 50)
                say("    %s  (%ld bytes)\n", path, (long)st.st_size);
            g_xav_count++;
        }
    }
    closedir(d);
}

/* ---- 2. list a directory ---------------------------------------------- */
static void list_dir(const char *dir)
{
    DIR *d = opendir(dir);
    if (!d) { say("  [cannot open %s: %s]\n", dir, strerror(errno)); return; }
    struct dirent *e;
    int n = 0;
    while ((e = readdir(d)) != NULL) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        char path[1024];
        snprintf(path, sizeof(path), "%s/%s", dir, e->d_name);
        struct stat st;
        if (stat(path, &st) == 0)
            say("  %s %s (%ld bytes)\n", S_ISDIR(st.st_mode) ? "[D]" : "[F]", e->d_name, (long)st.st_size);
        else
            say("  [?] %s\n", e->d_name);
        if (++n >= 200) { say("  ... truncated\n"); break; }
    }
    closedir(d);
}

/* ---- file helpers ------------------------------------------------------ */
static unsigned char *read_all(const char *path, size_t *len)
{
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long sz = ftell(f);
    if (sz < 0 || sz > (8L * 1024 * 1024)) { fclose(f); return NULL; }
    rewind(f);
    unsigned char *buf = (unsigned char *)malloc(sz ? (size_t)sz : 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    if (got != (size_t)sz) { free(buf); return NULL; }
    *len = (size_t)sz;
    return buf;
}

static int write_all(const char *path, const unsigned char *buf, size_t len)
{
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    size_t put = fwrite(buf, 1, len, f);
    int rc = fclose(f);
    return (put == len && rc == 0) ? 0 : -1;
}

static int is_avatar_file(const char *name)
{
    return !strncmp(name, "avatar", 6) || !strncmp(name, "picture", 7) || !strcmp(name, "online.json");
}

/* ---- 3. write test + 4. backup ------------------------------------------ */
/* Can we create (and delete) a brand-new file in this folder? */
static void probe_create(const char *dir)
{
    char p[1024];
    snprintf(p, sizeof(p), "%s/.xavatar_probe", dir);
    const unsigned char x = 'x';
    if (write_all(p, &x, 1) == 0) { say("    create-test: OK\n"); unlink(p); }
    else say("    create-test: FAILED (%s)\n", strerror(errno));
}

/* Safe overwrite test: back up each avatar file, then rewrite it with its own bytes and verify. */
static void backup_and_rewrite(const char *id, const char *dir)
{
    char bdir[1024];
    snprintf(bdir, sizeof(bdir), "%s/%s", BACKUP_DIR, id);
    if (mkdir_p(bdir) != 0) { say("    backup folder FAILED (%s)\n", strerror(errno)); return; }

    DIR *d = opendir(dir);
    if (!d) { say("    cannot open profile folder\n"); return; }
    struct dirent *e;
    int files = 0, backed = 0, rewrote = 0, failed = 0;
    while ((e = readdir(d)) != NULL) {
        if (!is_avatar_file(e->d_name)) continue;
        char src[1024], dst[1024];
        snprintf(src, sizeof(src), "%s/%s", dir, e->d_name);
        snprintf(dst, sizeof(dst), "%s/%s", bdir, e->d_name);
        size_t len = 0;
        unsigned char *buf = read_all(src, &len);
        files++;
        if (!buf) { say("    read FAILED: %s\n", e->d_name); failed++; continue; }
        if (write_all(dst, buf, len) == 0) backed++;
        else { say("    backup FAILED: %s\n", e->d_name); failed++; free(buf); continue; }
        if (write_all(src, buf, len) == 0) {
            size_t len2 = 0;
            unsigned char *chk = read_all(src, &len2);
            if (chk && len2 == len && memcmp(chk, buf, len) == 0) rewrote++;
            else { say("    verify FAILED: %s\n", e->d_name); failed++; }
            free(chk);
        } else {
            say("    overwrite FAILED: %s (%s)\n", e->d_name, strerror(errno));
            failed++;
        }
        free(buf);
    }
    closedir(d);
    say("    avatar files found=%d backed-up=%d rewritten-OK=%d failures=%d\n",
        files, backed, rewrote, failed);
}

static void show_username(const char *id)
{
    char p[1024];
    snprintf(p, sizeof(p), "%s/%s/username.dat", ROOT_HOME, id);
    size_t len = 0;
    unsigned char *b = read_all(p, &len);
    if (!b) { say("    username.dat: not readable\n"); return; }
    char name[65] = {0};
    size_t n = len < 64 ? len : 64;
    for (size_t i = 0; i < n; i++) name[i] = (b[i] >= 32 && b[i] < 127) ? (char)b[i] : '.';
    say("    username.dat: \"%s\" (%zu bytes)\n", name, len);
    free(b);
}

static void copy_report_to_usb(void)
{
    for (int i = 0; i < 8; i++) {
        char usb[64], dst[128];
        snprintf(usb, sizeof(usb), "%s%d", ROOT_USB, i);
        if (!is_dir(usb)) continue;
        snprintf(dst, sizeof(dst), "%s/xavatar_diag_report.txt", usb);
        size_t len = 0;
        unsigned char *b = read_all(REPORT, &len);
        if (b && write_all(dst, b, len) == 0) printf("report copied to %s\n", dst);
        free(b);
    }
}

int main(void)
{
    mkdir_p(WORK_DIR);
    g_log = fopen(REPORT, "w");

    say("=== XAvatar Changer diagnostic v0.1 ===\n");
    say("report file: %s%s\n\n", REPORT, g_log ? "" : "  (COULD NOT OPEN - console output only)");

    say("[1] .xavatar search\n");
    const char *roots[] = { ROOT_DATA "/AVATARS", ROOT_DATA };
    for (int i = 0; i < 2; i++) {
        say("  in %s\n", roots[i]);
        scan_xavatar(roots[i], i == 0 ? 3 : 2);
    }
    for (int i = 0; i < 8; i++) {
        char usb[64];
        snprintf(usb, sizeof(usb), "%s%d", ROOT_USB, i);
        if (is_dir(usb)) { say("  in %s\n", usb); scan_xavatar(usb, 3); }
    }
    say("  total .xavatar found: %d\n\n", g_xav_count);

    say("[2] user folders in %s\n", ROOT_HOME);
    DIR *h = opendir(ROOT_HOME);
    if (!h) say("  [cannot open: %s]\n", strerror(errno));
    else {
        struct dirent *e;
        while ((e = readdir(h)) != NULL) {
            if (e->d_name[0] == '.') continue;
            say("  user id: %s\n", e->d_name);
            show_username(e->d_name);
        }
        closedir(h);
    }
    say("\n");

    say("[3] profile cache in %s\n", ROOT_PROFILE);
    DIR *p = opendir(ROOT_PROFILE);
    if (!p) say("  [cannot open: %s]\n", strerror(errno));
    else {
        struct dirent *e;
        while ((e = readdir(p)) != NULL) {
            if (e->d_name[0] == '.') continue;
            char dir[1024];
            snprintf(dir, sizeof(dir), "%s/%s", ROOT_PROFILE, e->d_name);
            if (!is_dir(dir)) continue;
            say("  profile folder: %s\n", e->d_name);
            list_dir(dir);
            probe_create(dir);
            backup_and_rewrite(e->d_name, dir);
        }
        closedir(p);
    }

    say("\n=== done. Backups are in %s ===\n", BACKUP_DIR);
    if (g_log) { fclose(g_log); g_log = NULL; }
    copy_report_to_usb();
    return 0;
}
