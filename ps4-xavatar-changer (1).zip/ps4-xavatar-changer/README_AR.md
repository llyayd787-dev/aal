# خطوات بناء الإصدار التشخيصي (بسيطة)

1. أنشئ حساباً مجانياً في github.com، ثم أنشئ مستودعاً جديداً (New repository) باسم xavatar-changer.
2. ارفع كل محتويات هذا المجلد إلى المستودع (Add file ← Upload files)، مع الحفاظ على مجلد `.github`.
3. افتح تبويب Actions ← Build PKG ← Run workflow. انتظر بضع دقائق.
4. إن نجح: نزّل الملف من Artifacts (xavatar-diagnostic). وإن فشل: انسخ آخر سطور السجل وأرسلها لي.
5. ثبّت الـPKG عبر GoldHEN، شغّل التطبيق مرة واحدة، ثم أرسل لي الملف /data/xavatar/diag_report.txt (أو الذي على الفلاشة).
