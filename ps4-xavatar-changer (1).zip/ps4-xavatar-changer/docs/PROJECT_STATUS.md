# PROJECT_STATUS — XAvatar Changer (PS4 13.52 + GoldHEN)

Updated: 2026-11-03
Milestone: M1 — Diagnostic build (v0.1)

## Stage status (honest)
| Stage | Status |
|---|---|
| Source files exist | yes (src/diag_main.c, workflow) |
| Host compile (gcc, fake file tree) | passed (with truncation warnings only) |
| Host run on fake tree | passed |
| PS4 compile/link (OpenOrbis) | NOT RUN — no toolchain/network in author's sandbox |
| FSELF / GP4 / PKG creation | NOT RUN |
| Install on console | NOT RUN |
| Runtime on console | NOT RUN |

## Added after M1 (host-verified only)
- src/core: xinflate, xzip, xdxt1, xname + tests/host_test.c (ALL PASSED on host with the user's real .xavatar)
- assets/icon0.png
- These are NOT yet compiled with OpenOrbis.

## Known blockers
- Cloud build workflow is untested; it reuses the official hello_world sample's Makefile and may need 1-2 fixes after the first log.
- No on-screen UI in v0.1: report is written to /data/xavatar/diag_report.txt (+ USB copy).

## Next single action
User uploads project to GitHub, runs "Build PKG", reports result (success/log).
