# TEST_PLAN (M1 diagnostic)
| # | Test | Result |
|---|---|---|
| 1 | Cloud build produces a .pkg | not-tested |
| 2 | PKG installs via GoldHEN Package Installer | not-tested |
| 3 | App launches and exits without crash | not-tested |
| 4 | Report shows .xavatar files found | not-tested |
| 5 | Report shows profile folders + file list | not-tested |
| 6 | create-test OK / rewrite-OK in profile folder | not-tested |
