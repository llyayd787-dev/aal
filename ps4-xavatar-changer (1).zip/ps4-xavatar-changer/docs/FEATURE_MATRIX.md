# FEATURE_MATRIX
| Feature | Status | Evidence / note |
|---|---|---|
| Find .xavatar in /data and USB | supported-with-constraints | libc dirent; real paths on 13.52 verified by diagnostic |
| Read .xavatar (ZIP) | verified-on-host | own ZIP+inflate: all 11 entries extracted, CRC OK, byte-identical to unzip (host test) |
| Decode thumbnails/preview (DXT1) | verified-on-host | decoded 128/440 images; PSNR 32.6 dB vs original PNG (normal DXT1 loss). PS4 build untested |
| Shortened names (UTF-8 safe) | verified-on-host | tests/host_test.c |
| App icon 512x512 | created | assets/icon0.png; acceptance by PKG tools untested |
| Apply to local profile | unverified | path/permission/refresh on 13.52 unknown until diagnostic |
| Undo (restore backup) | supported-with-constraints | depends on write permission |
| Large preview (avatar.png) | unverified | needs PNG decode + rendering approach verified in toolchain |
| Show local account name | unverified | username.dat readability tested by diagnostic |
| Arabic UI (shaping/RTL) | unverified | font/text rendering path not yet chosen |
| Dark mode + blue theme | supported-with-constraints | depends on rendering path |
| Settings/creator info | pending user input | user will provide info when asked |
