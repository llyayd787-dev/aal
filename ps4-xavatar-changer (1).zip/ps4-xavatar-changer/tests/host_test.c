/* Host-side tests (run on a PC): ZIP + inflate + DXT1 + names, using a real .xavatar file. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../src/core/xzip.h"
#include "../src/core/xdxt1.h"
#include "../src/core/xname.h"

static int fails = 0;
#define CHECK(c, msg) do { if (c) printf("PASS  %s\n", msg); else { printf("FAIL  %s\n", msg); fails++; } } while (0)

int main(int argc, char **argv)
{
    if (argc < 3) { fprintf(stderr, "usage: host_test file.xavatar outdir\n"); return 2; }
    FILE *f = fopen(argv[1], "rb"); if (!f) return 2;
    fseek(f, 0, SEEK_END); long n = ftell(f); rewind(f);
    uint8_t *buf = malloc(n); if (fread(buf, 1, n, f) != (size_t)n) return 2; fclose(f);

    xzip_t z; CHECK(xzip_open(&z, buf, n) == 0, "zip opens");
    CHECK(z.count == 11, "zip has 11 entries");
    int ok_all = 1;
    for (int i = 0; i < z.count; i++) {
        xzip_entry_t e; size_t len = 0;
        if (xzip_entry(&z, i, &e)) { ok_all = 0; continue; }
        uint8_t *d = xzip_extract(&z, &e, &len);
        if (!d) { printf("  extract failed: %s\n", e.name); ok_all = 0; continue; }
        char p[512]; snprintf(p, sizeof p, "%s/%s", argv[2], e.name);
        FILE *o = fopen(p, "wb"); fwrite(d, 1, len, o); fclose(o); free(d);
    }
    CHECK(ok_all, "all entries extract with CRC OK");

    xzip_entry_t e; size_t len; int w = 0, h = 0;
    CHECK(xzip_find(&z, "avatar128.dds", &e) == 0, "find avatar128.dds");
    uint8_t *dds = xzip_extract(&z, &e, &len);
    uint8_t *rgba = dds ? xdxt1_decode(dds, len, &w, &h) : NULL;
    CHECK(rgba && w == 128 && h == 128, "decode avatar128 -> 128x128");
    if (rgba) { char p[512]; snprintf(p, sizeof p, "%s/decoded128.rgba", argv[2]); FILE *o = fopen(p, "wb"); fwrite(rgba, 1, (size_t)w*h*4, o); fclose(o); }
    free(rgba); free(dds);
    CHECK(xzip_find(&z, "avatar440.dds", &e) == 0 && (dds = xzip_extract(&z, &e, &len)) && (rgba = xdxt1_decode(dds, len, &w, &h)) && w == 440, "decode avatar440 -> 440x440");
    if (rgba) { char p[512]; snprintf(p, sizeof p, "%s/decoded440.rgba", argv[2]); FILE *o = fopen(p, "wb"); fwrite(rgba, 1, (size_t)w*h*4, o); fclose(o); }

    char nm[64];
    xname_short("/data/AVATARS/avatar_1938906865_16156.xavatar", nm, sizeof nm, 14);
    printf("  name -> '%s'\n", nm); CHECK(strlen(nm) <= 16 && strstr(nm, "..") != NULL, "long name shortened");
    xname_short("/mnt/usb0/Cool.XAVATAR", nm, sizeof nm, 14);
    CHECK(strcmp(nm, "Cool") == 0, "short name kept, extension removed");
    xname_short("/x/\xd9\x85\xd9\x8a\xd9\x86\xd9\x8a\xd9\x85\xd9\x8a\xd9\x86\xd9\x8a\xd9\x85\xd9\x8a\xd9\x86\xd9\x8a\xd9\x85\xd9\x8a\xd9\x86\xd9\x8a.xavatar", nm, sizeof nm, 8);
    printf("  arabic name -> '%s'\n", nm);
    int bad = 0; for (const unsigned char *c = (unsigned char*)nm; *c; c++) if ((*c & 0xC0) == 0x80 && (c == (unsigned char*)nm)) bad = 1;
    CHECK(!bad, "UTF-8 not cut mid-character");
    printf(fails ? "\n%d FAILED\n" : "\nALL PASSED\n", fails);
    return fails != 0;
}
